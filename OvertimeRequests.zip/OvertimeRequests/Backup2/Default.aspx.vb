Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/Default.aspx.vb 2     1/18/12 4:24p Vhaclemauref $
'
Partial Public Class _Default
    Inherits System.Web.UI.Page

#Region "Methods"
    Protected Sub MainMenu_MenuItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ' hide menu item logic
        ApplicationFunctions.SetMenu(e, User)

        ' display external links in a new browser window
        If Not Page.IsPostBack Then
            If e.Item.NavigateUrl.StartsWith("http://") OrElse e.Item.NavigateUrl.StartsWith("https://") Then
                e.Item.Target = "_blank"
            End If
        End If
    End Sub
#End Region

#Region "Page Events"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.SetSecurity(ApplicationGlobals.APPLICATION_ID)

        ' ONLY the application HOME page (default.aspx) calls SetSecurity()
        ' ALL other web pages need to call CheckSecurity()
        'Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)

        Master.EnableMedicalCenterDDLB()    ' application Home page ONLY

        'If Master.CommonSecurity.IsRoleAvailable(ApplicationGlobals.ROLE_REPORTS) Or _
        ' Master.CommonSecurity.IsRoleAvailable(CommonGlobals.ROLE_SYSTEM_ADMIN) Then
        '    IsReports_ = True
        'Else
        '    IsReports_ = False
        'End If
    End Sub
#End Region

End Class