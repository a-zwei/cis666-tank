Imports System.Linq

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ApplicationFunctions.vb 5     5/17/12 2:54p Vhaclemauref $
'
' Common functions to this application
Public Class ApplicationFunctions

	' hide menu item logic
    Public Shared Sub SetMenu(ByVal e As System.Web.UI.WebControls.MenuEventArgs, user As System.Security.Principal.IPrincipal)
        If e.Item.Text = "All Requests" Then
            If Not user.IsInRole(ApplicationGlobals.MANAGER) Then
                e.Item.Parent.ChildItems.Remove(e.Item)
            End If
        End If
    End Sub

    Public Shared Function NameFromNetworkID(id As String) As String
        If String.IsNullOrEmpty(id) Then
            Return ""
        Else
            Using dc As New IRMStaffDataContext
                Dim reverseName As String = (From e In dc.Employees Where e.NetworkID.ToLower() = id.ToLower() Select e.Name).SingleOrDefault
                If String.IsNullOrEmpty(reverseName) Then
                    Return String.Format("[{0}]", id)
                Else
                    Dim ename As String() = reverseName.Split(",")
                    Return String.Format("{0} {1}", ename(1).Trim(), ename(0).Trim())
                End If
            End Using
            'Dim fname, lname As String

            'CommonFunctions.GetActiveDirectoryInfo(id, fname, lname, Nothing, Nothing, Nothing)
            'Return String.Format("{0} {1}", fname, lname)
        End If
    End Function
End Class
