Imports System.Web.SessionState
Imports System.Diagnostics
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/Global.asax.vb 1     1/10/12 11:55a Vhaclemauref $
'
Public Class Global_asax
	Inherits System.Web.HttpApplication

    ' Fires when an error occurs
	Private Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
		Dim ApplicationName As String = ""
		Dim AppErrorEmailAddress As String
		Dim NetworkID As String
		Dim SourceFilename As String
		Dim SlashPos As Integer
		Dim ErrorDescription As String
		Dim MyException As Exception = HttpContext.Current.Server.GetLastError()

		If TypeOf MyException Is HttpUnhandledException AndAlso MyException.InnerException IsNot Nothing Then
			MyException = MyException.InnerException
		End If

		NetworkID = HttpContext.Current.User.Identity.Name

		If MyException IsNot Nothing Then
			Try
				' Variables defined in Web.config
				' If a variable is missing from the Web.config file, an exception error
				' would have already been thrown in Page_Init() in Common.Master.vb
				ApplicationName = CommonFunctions.GetAppSettings("ApplicationName")
				If ApplicationName Is Nothing Then
					ApplicationName = ""
				End If
				AppErrorEmailAddress = CommonFunctions.GetAppSettings("AppErrorEmailAddress")
				If AppErrorEmailAddress Is Nothing Then
					AppErrorEmailAddress = ""
				End If

				'
				' Send Email to Developer
				'
				' Email the System Admin. with information that an error has occured
				If AppErrorEmailAddress.Length > 0 Then
					' Strip-off filename path for email subject (shorten it)
					SlashPos = Request.Path.LastIndexOf("/")
					If SlashPos > 0 Then
						SourceFilename = Request.Path.Substring(SlashPos + 1)
					Else
						SourceFilename = Request.Path
					End If

					' Create the MailMessage instance
					Dim MailMsg As New System.Net.Mail.MailMessage(AppErrorEmailAddress, AppErrorEmailAddress)

					' Assign the MailMessage's properties
					MailMsg.Subject = ApplicationName & " Application Exception Error - " & SourceFilename
					MailMsg.Body = "<html><body><b>Source File: " & Request.Path & "<br />Network ID: " & NetworkID & "</b><br /><br />" _
					 & "(See CommonVHACLE.APPLICATION_ERROR_LOG table for SQL type exceptions)<br />" _
					 & "(Also see Windows Event Log entry)<br /><br />" & MyException.ToString & "</body></html>"
					''MailMsg.Body = String.Format("An unhandled exception occurred:{0}Message: {1}{0}{0}Stack Trace:{0}{2}", _
					'' System.Environment.NewLine, MyException.Message, MyException.StackTrace)
					MailMsg.IsBodyHtml = True

					' Create the SmtpClient object
					Dim smtp As New System.Net.Mail.SmtpClient

					' Send the MailMessage (will use the Web.config settings)
					smtp.Send(MailMsg)

					' Needed cleanup
					MailMsg.Dispose()
					MailMsg = Nothing
				End If
			Catch
				' Problem sending email... Just send the user onto ErrorMessage page.
			End Try

			'
			' Write Windows Event Log
			'
			Try
				ErrorDescription = ApplicationName & " Application Exception Error" & System.Environment.NewLine _
				 & "Source File: " & Request.Path & System.Environment.NewLine & "Network ID: " & NetworkID _
				 & System.Environment.NewLine & System.Environment.NewLine & MyException.ToString

				'Creation of event log if it does not exist
				Dim EventLogName As String = "Web Application"
				Dim EventSourceName As String = "WebApplication"
				If (Not EventLog.SourceExists(EventSourceName)) Then
					EventLog.CreateEventSource(EventSourceName, EventLogName)
				End If

				' Inserting into event log
				Dim Log As New EventLog()
				Log.Source = EventSourceName
				Log.WriteEntry(ErrorDescription, EventLogEntryType.Error)
			Catch
				' Problem writing to log... Just send the user onto ErrorMessage page.
			End Try

			' ApplicationException errors set mainly in CommonClassLib (CommonGlobals, CommonFunctions, CommonSecurity)
			' UnrecoverableError page has no Master page which prevents CommonSecurity from running a second time and messing things up.
			If TypeOf MyException Is ApplicationException Then
				Server.Transfer("~/UnrecoverableError.aspx")
			Else
				Server.Transfer("~/ApplicationError.aspx")
			End If
		End If
	End Sub

End Class
