﻿Imports System.Linq
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ResolveRequest.aspx.vb 4     2/10/12 5:07p Vhaclemauref $
'
Public Class ResolveRequest
    Inherits System.Web.UI.Page

    Protected otRequest As OT_Request

    Protected Function UserOwnsRequest()
        Dim user As String = CommonFunctions.GetNetworkID().ToLower()
        Return otRequest.Employee = user OrElse otRequest.EnteredBy = user OrElse otRequest.CreatedBy.ToLower() = user
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)

        Dim reqid As String = Request.QueryString("id")
        If reqid IsNot Nothing Then
            Using dc As New OT_RequestDataContext(Master.DbConnectionString)
                otRequest = dc.OT_Requests.Single(Function(r) r.SID = CInt(reqid))
                DeletedLabel.Visible = otRequest.SoftDelete
                If Not IsPostBack AndAlso Not otRequest.SoftDelete Then
                    FillFields()
                End If
            End Using
        End If
    End Sub

    Protected Sub RequestDataSource_ContextCreating(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceContextEventArgs) Handles RequestDataSource.ContextCreating
        e.ObjectInstance = New OT_RequestDataContext(Master.DbConnectionString)
    End Sub

    Private Sub FillFields()
        If Not IsPostBack Then
            BeginDateCalendar.SelectedDate = otRequest.BeginDate
            BeginTimeTextBox.Text = otRequest.BeginTimeDisp
            EndDateCalendar.SelectedDate = otRequest.EndDate
            EndTimeTextBox.Text = otRequest.EndTimeDisp
            WorkedFromTextBox.Text = otRequest.WorkedFrom
            POCTextBox.Text = otRequest.MedicalCenterPOC
            DetailsTextBox.Text = otRequest.WorkDetails
            ResolutionTextBox.Text = otRequest.Resolution
        End If
    End Sub

    Protected Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        Using dc As New OT_RequestDataContext(Master.DbConnectionString)
            dc.ResolveRequest(otRequest.SID, CommonFunctions.GetNetworkID(), BeginDateCalendar.SelectedDate,
                              BeginTimeTextBox.Text, EndDateCalendar.SelectedDate, EndTimeTextBox.Text,
                              WorkedFromTextBox.Text, POCTextBox.Text, DetailsTextBox.Text,
                              ResolutionTextBox.Text)
            dc.SubmitChanges()
        End Using

        Response.Redirect("~/ViewRequest.aspx?id=" & otRequest.SID)
    End Sub

    Protected Sub MainMenu_MenuItemDataBound(sender As Object, e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ApplicationFunctions.SetMenu(e, User)
    End Sub
End Class