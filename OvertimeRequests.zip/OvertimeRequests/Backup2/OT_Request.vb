Imports System.Linq
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/OT_Request.vb 9     10/03/13 10:20a Vhaclemauref $
'
Partial Class OT_RequestDataContext
    Public Sub SetEmployeeSupervisor(employee As String, supervisor As String)
        Dim s As DefaultSupervisor = DefaultSupervisors.SingleOrDefault(Function(ds) ds.Employee = employee)
        If s Is Nothing Then
            s = New DefaultSupervisor
            DefaultSupervisors.InsertOnSubmit(s)
        End If

        s.Employee = employee
        s.Supervisor = supervisor
    End Sub

    Public Sub SetEmployeeServiceLine(employee As String, serviceLineSID As Integer)
        Dim s As DefaultServiceLine = DefaultServiceLines.SingleOrDefault(Function(ds) ds.Employee = employee)
        If s Is Nothing Then
            s = New DefaultServiceLine
            DefaultServiceLines.InsertOnSubmit(s)
        End If

        s.Employee = employee
        s.ServiceLineSID = serviceLineSID
    End Sub

    Public Sub NewRequest(request As OT_Request)
        Dim user As String = CommonFunctions.GetNetworkID()
        request.SoftDelete = False
        request.DateCreated = Now
        request.CreatedBy = user
        request.DateModified = Now
        request.ModifiedBy = user
        request.Decision = Decisions.Single(Function(d) d.Name = "Pending")
        OT_Requests.InsertOnSubmit(request)

        SetEmployeeSupervisor(request.Employee, request.Supervisor)
        SetEmployeeServiceLine(request.Employee, request.ServiceLineSID)

        SubmitChanges()

        Notifier.NewRequest(request, CommonFunctions.GetAppSettings("NewRequestNotify"))
    End Sub

    Public Sub DeleteRequest(requestId As Integer, user As String)
        Dim request As OT_Request = OT_Requests.Single(Function(r) r.SID = requestId)
        request.SoftDelete = True
        request.ModifiedBy = user
        request.DateModified = Now
    End Sub

    Public Sub DecideRequest(requestId As Integer, user As String, decisionID As Integer)
        Dim request As OT_Request = OT_Requests.Single(Function(r) r.SID = requestId)
        If request.DecisionSID <> decisionID Then
            request.DecisionSID = decisionID
            request.DecisionBy = user
            request.ApprovalDate = Now
            request.ModifiedBy = user
            request.DateModified = Now

            If Not request.RequestType.ResolutionRequired AndAlso request.Decision.Name = "Approved" Then
                ' resolve the request automatically
                request.ActualBeginDate = request.BeginDate
                request.ActualBeginTime = request.BeginTime
                request.ActualEndDate = request.EndDate
                request.ActualEndTime = request.EndTime
                request.ActualTotalHours = request.ActualTotalHoursComp
                request.ResolutionDate = Now
            End If

            Notifier.Decision(request)
        End If
    End Sub

    Public Sub ResolveRequest(requestId As Integer, user As String, actualBeginDate As Date,
        actualBeginTime As Integer, actualEndDate As Date, actualEndTime As Integer,
        actualWorkedFrom As String, actualPOC As String, actualDetails As String, resolution As String)
        Dim request As OT_Request = OT_Requests.Single(Function(r) r.SID = requestId)
        If Not request.IsResolved Then
            request.ActualBeginDate = actualBeginDate
            request.ActualBeginTime = actualBeginTime
            request.ActualEndDate = actualEndDate
            request.ActualEndTime = actualEndTime
            request.ActualTotalHours = request.ActualTotalHoursComp
            request.WorkedFrom = actualWorkedFrom
            request.MedicalCenterPOC = actualPOC
            request.WorkDetails = actualDetails
            request.Resolution = resolution
            request.ResolutionDate = Now
            request.ModifiedBy = user
            request.DateModified = Now

            Notifier.Resolution(request, CommonFunctions.GetAppSettings("NewRequestNotify"))
        End If
    End Sub
End Class

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/OT_Request.vb 9     10/03/13 10:20a Vhaclemauref $
'
Partial Class OT_Request
    Public ReadOnly Property EmployeeName As String
        Get
            Return ApplicationFunctions.NameFromNetworkID(Employee)
            'Using dc As New IRMStaffDataContext
            '    Return (From e In dc.Employees Where e.NetworkID.ToLower() = Employee Select e.Name).Single()
            'End Using
        End Get
    End Property

    Public ReadOnly Property SupervisorName As String
        Get
            Return ApplicationFunctions.NameFromNetworkID(Supervisor)
            'Using dc As New IRMStaffDataContext
            '    Return (From e In dc.Employees Where e.NetworkID.ToLower() = Supervisor Select e.Name).Single()
            'End Using
        End Get
    End Property

    Public ReadOnly Property EnteredByName As String
        Get
            Return ApplicationFunctions.NameFromNetworkID(EnteredBy)
            'Using dc As New IRMStaffDataContext
            '    Return (From e In dc.Employees Where e.NetworkID.ToLower() = EnteredBy Select e.Name).Single()
            'End Using
        End Get
    End Property

    Public ReadOnly Property DecisionByName As String
        Get
            Return ApplicationFunctions.NameFromNetworkID(DecisionBy)
        End Get
    End Property

    Public ReadOnly Property WorkDetailsHTML As String
        Get
            Return HttpContext.Current.Server.HtmlEncode(WorkDetails).Replace(Environment.NewLine, "<br />")
            'Return New HtmlString(WorkDetails).ToHtmlString().Replace(Environment.NewLine, "<br />")
        End Get
    End Property

    Public ReadOnly Property ResolutionHTML As String
        Get
            Return HttpContext.Current.Server.HtmlEncode(If(Resolution, "")).Replace(Environment.NewLine, "<br />")
        End Get
    End Property

    Public ReadOnly Property PayCompDisp As String
        Get
            Return If(PayComp = "P", "OT", "CT")
        End Get
    End Property

    Public ReadOnly Property IsPending As Boolean
        Get
            Return Decision.Name = "Pending"
        End Get
    End Property

    Public ReadOnly Property IsDecided As Boolean
        Get
            Return Not IsPending
        End Get
    End Property

    Public ReadOnly Property BeginDateTime As Date?
        Get
            If BeginDate.HasValue Then
                Return BeginDate.Value.Date.AddHours(BeginTime \ 100).AddMinutes(BeginTime Mod 100)
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property EndDateTime As Date?
        Get
            If EndDate.HasValue Then
                Return EndDate.Value.Date.AddHours(EndTime \ 100).AddMinutes(EndTime Mod 100)
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property TotalHoursComp As Double?
        Get
            If BeginDateTime.HasValue AndAlso EndDateTime.HasValue Then
                Return (EndDateTime.Value - BeginDateTime.Value).TotalHours
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property ActualBeginDateTime As Date?
        Get
            If ActualBeginDate.HasValue Then
                Return ActualBeginDate.Value.Date.AddHours(ActualBeginTime \ 100).AddMinutes(ActualBeginTime Mod 100)
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property ActualEndDateTime As Date?
        Get
            If ActualEndDate.HasValue Then
                Return ActualEndDate.Value.Date.AddHours(ActualEndTime \ 100).AddMinutes(ActualEndTime Mod 100)
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property ActualTotalHoursComp As Double?
        Get
            If ActualBeginDateTime.HasValue AndAlso ActualEndDateTime.HasValue Then
                Return (ActualEndDateTime.Value - ActualBeginDateTime.Value).TotalHours
            Else : Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property CanDecide As Boolean
        Get
            Return Not SoftDelete AndAlso BeginDateTime.HasValue AndAlso Now < BeginDateTime.Value.AddDays(14)
        End Get
    End Property

    Public ReadOnly Property IsResolved As Boolean
        Get
            Return Not IsNothing(ResolutionDate)
        End Get
    End Property

    Public ReadOnly Property BeginTimeDisp As String
        Get
            Return BeginTime.ToString().PadLeft(4, "0")
        End Get
    End Property

    Public ReadOnly Property EndTimeDisp As String
        Get
            Return EndTime.ToString().PadLeft(4, "0")
        End Get
    End Property

    Public ReadOnly Property ActualBeginTimeDisp As String
        Get
            Return ActualBeginTime.ToString().PadLeft(4, "0")
        End Get
    End Property

    Public ReadOnly Property ActualEndTimeDisp As String
        Get
            Return ActualEndTime.ToString().PadLeft(4, "0")
        End Get
    End Property

    Public ReadOnly Property Status As String
        Get
            If IsResolved Then
                Return "Resolved"
            Else
                Return Decision.Name
            End If
        End Get
    End Property
End Class

Partial Class RequestType
    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class

Partial Class ServiceLine
    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class

Partial Class Decision
    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class

