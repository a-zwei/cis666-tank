Imports System
Imports System.ComponentModel
Imports System.Security.Permissions
Imports System.Web
Imports System.Web.UI.WebControls

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ValidationSummary.vb 1     1/10/12 11:55a Vhaclemauref $
'
' This control inherits the ASP.NET ValidationSummary control, but adds the
' ability to dynamically add messages without requiring validation controls.
Public Class ValidationSummary
	Inherits System.Web.UI.WebControls.ValidationSummary

#Region "Public Property Methods"
	' Returns true if a validator on page is invalid; otherwise false.
	<Browsable(False)> _
	Public ReadOnly Property HasMessages() As Boolean
		Get
			For Each Validator As BaseValidator In Me.Page.Validators
				If (Validator.ValidationGroup = MyBase.ValidationGroup) And Validator.IsValid = False Then
					Return True
				End If
			Next

			Return False
		End Get
	End Property
#End Region

#Region "Methods"
	' Allows the caller to place custom text messages inside the Validation Summary control.
	Public Sub AddMessage(ByVal Message As String)
		Me.Page.Validators.Add(New Validator(Me, Message))
	End Sub

	' Allows the caller to place custom formatted text messages inside the Validation Summary control.
	Public Sub AddFormattedMessage(ByVal Format As String, ByVal ParamArray args As Object())
		Dim Message As String

		Message = String.Format(Format, args)
		Me.Page.Validators.Add(New Validator(Me, Message))
	End Sub

	' Allows the caller to place exception messages inside the Validation Summary control
	Public Sub AddError(ByVal ex As Exception)
		Dim Message As String

		Message = IIf(ex.InnerException IsNot Nothing, ex.InnerException.Message, ex.Message).ToString
		Me.Page.Validators.Add(New Validator(Me, Message))
	End Sub
#End Region

#Region "Associated Class Constructors"
	' The Validation Summary control works by iterating over the Page.Validators collection and
	' displaying the ErrorMessage property of each validator that return false for the IsValid()
	' property. This class will act like all the other validators except it always is invalid and
	' thus the ErrorMessage property will always be displayed.
	Friend Class Validator
		Inherits BaseValidator

		Public Sub New(ByVal ValidationSummary As ValidationSummary, ByVal ErrorMessage As String)
			MyBase.ValidationGroup = ValidationSummary.ValidationGroup
			MyBase.ErrorMessage = ErrorMessage
			MyBase.IsValid = False
		End Sub

		Protected Overrides Function EvaluateIsValid() As Boolean
			Return False
		End Function
	End Class
#End Region

End Class
