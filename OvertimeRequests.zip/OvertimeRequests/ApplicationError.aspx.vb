Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ApplicationError.aspx.vb 1     1/10/12 11:55a Vhaclemauref $
'
Partial Public Class ApplicationError
	Inherits System.Web.UI.Page

#Region "Data"
	Protected EmailMessageText_ As String
#End Region

#Region "Page Events"
	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		Dim ApplicationName As String = ""
		Dim AppErrorEmailAddress As String = ""
		Dim NetworkID As String
		Dim EmailLink As String
		Dim Dummy As Boolean

		Master.EnableMedicalCenterDDLB()

		Try
			' Variables defined in Web.config
			' If a variable is missing from the Web.config file, an exception error
			' would have already been thrown in Page_Init() in Common.Master.vb
			ApplicationName = CommonFunctions.GetAppSettings("ApplicationName")
			If ApplicationName Is Nothing Then
				ApplicationName = ""
			End If
			AppErrorEmailAddress = CommonFunctions.GetAppSettings("AppErrorEmailAddress")
			If AppErrorEmailAddress Is Nothing Then
				AppErrorEmailAddress = ""
			End If
		Catch
			' Missing appSetting variable in Web.config file... keep processing.
		End Try

		If AppErrorEmailAddress.Length > 0 Then
			EmailLink = "<a href=""mailto:" & AppErrorEmailAddress & "?subject=" & ApplicationName & " Application Exception Error - User Information"">" _
			 & AppErrorEmailAddress & "</a>"
			EmailMessageText_ = "<tr><td>&nbsp;</td><td>Please retry your last action and if the problem persists, contact technical support at " _
			 & EmailLink & ".</td></tr><tr><td>&nbsp;</td><td>Please include all of the information needed to recreate the problem in your email.</td></tr>"
		Else
			EmailMessageText_ = "<tr><td>&nbsp;</td><td>Please retry your last action and if the problem persists, contact technical support.</td></tr>"
		End If

		' Called just to set System Admin. variable
		Dummy = Master.CommonSecurity.IsFeatureAvailable(-1)
		' Display Exception Error Information to System Admins.
		If Master.CommonSecurity.IsSystemAdmin() = True Then
			NetworkID = HttpContext.Current.User.Identity.Name
			Dim MyException As Exception = HttpContext.Current.Server.GetLastError()

			If TypeOf MyException Is HttpUnhandledException AndAlso MyException.InnerException IsNot Nothing Then
				MyException = MyException.InnerException
			End If

			If MyException IsNot Nothing Then
				ExceptionErrorText.Text = ApplicationName & " Application Exception Error<br />Source File: " & Request.Path & "<br />Network ID: " _
				 & NetworkID & "<br /><br />(See CommonVHACLE.APPLICATION_ERROR_LOG table for SQL type exceptions)<br />" _
				 & "(Also see Windows Event Log entry)<br /><br />" & MyException.ToString
			End If
		End If

		Server.ClearError()
	End Sub
#End Region

End Class
