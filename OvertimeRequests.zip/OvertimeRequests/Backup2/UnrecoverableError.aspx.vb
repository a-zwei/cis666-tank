'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/UnrecoverableError.aspx.vb 1     1/10/12 11:55a Vhaclemauref $
'
Partial Public Class UnrecoverableError
    Inherits System.Web.UI.Page

#Region "Page Events"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim MyException As Exception = HttpContext.Current.Server.GetLastError()

        If TypeOf MyException Is HttpUnhandledException AndAlso MyException.InnerException IsNot Nothing Then
            MyException = MyException.InnerException
        End If

        If MyException IsNot Nothing Then
            ExceptionErrorText.Text = MyException.Message
        End If

        Server.ClearError()
    End Sub
#End Region

End Class