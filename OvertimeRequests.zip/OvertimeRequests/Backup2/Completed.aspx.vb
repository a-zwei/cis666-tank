﻿Public Class Completed
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)
    End Sub

    Protected Sub RequestDataSource_ContextCreating(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceContextEventArgs) Handles RequestDataSource.ContextCreating
        e.ObjectInstance = New OT_RequestDataContext(Master.DbConnectionString)
    End Sub

    Protected Sub RequestGridView_SelectedIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles RequestGridView.SelectedIndexChanging
        Response.Redirect("~/ViewRequest.aspx?id=" & RequestGridView.DataKeys(e.NewSelectedIndex).Value)
    End Sub

    Protected Sub MainMenu_MenuItemDataBound(sender As Object, e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ApplicationFunctions.SetMenu(e, User)
    End Sub
End Class