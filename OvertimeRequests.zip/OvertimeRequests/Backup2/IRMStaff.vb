Imports System.Linq

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/IRMStaff.vb 5     10/09/12 11:29a Vhaclemauref $
'
Partial Class IRMStaffDataContext
    Public Function UserIsSupervisor(networkID As String) As Boolean
        Return If((From e In Employees Where e.NetworkID.ToLower() = networkID.ToLower() Select e.IsSupervisor).SingleOrDefault(), False)
    End Function
End Class

Partial Class Employee
    Public ReadOnly Property LCNetworkID
        Get
            Return NetworkID.ToLower()
        End Get
    End Property
End Class