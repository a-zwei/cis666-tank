﻿Imports System.Net.Mail
Imports VHACLE.CommonClassLib.CommonVHACLE

Public Module Notifier
    'Private Sub SetEmployeeSupervisor(employee As String, supervisor As String)
    '    Using dc As New OT_RequestDataContext(connection)
    '        Dim s As DefaultSupervisor = (From ds In dc.DefaultSupervisors Where ds.Employee = employee Select ds).SingleOrDefault()
    '        If s Is Nothing Then
    '            s = New DefaultSupervisor
    '            dc.DefaultSupervisors.InsertOnSubmit(s)
    '        End If
    '        s.Employee = employee
    '        s.Supervisor = supervisor
    '        dc.SubmitChanges()
    '    End Using
    'End Sub

    'Private Sub SetEmployeeServiceLine(employee As String, serviceLineSID As Integer)
    '    Using dc As New OT_RequestDataContext(connection)
    '        Dim s As DefaultServiceLine = (From ds In dc.DefaultServiceLines Where ds.Employee = employee Select ds).SingleOrDefault()
    '        If s Is Nothing Then
    '            s = New DefaultServiceLine
    '            dc.DefaultServiceLines.InsertOnSubmit(s)
    '        End If
    '        s.Employee = employee
    '        s.ServiceLineSID = serviceLineSID
    '        dc.SubmitChanges()
    '    End Using
    'End Sub

    'Public Sub SubmitRequest(request As OT_Request)
    '    Dim user As String = CommonFunctions.GetNetworkID()
    '    request.SoftDelete = False
    '    request.DateCreated = Now
    '    request.CreatedBy = user
    '    request.DateModified = Now
    '    request.ModifiedBy = user
    '    Using dc As New OT_RequestDataContext(connection)
    '        request.Decision = (From d In dc.Decisions Where d.Name = "Pending" Select d).Single()
    '        dc.OT_Requests.InsertOnSubmit(request)
    '        dc.SetEmployeeSupervisor(request.Employee, request.Supervisor)
    '        dc.SetEmployeeServiceLine(request.Employee, request.ServiceLineSID)
    '        dc.SubmitChanges()
    '    End Using

    '    NotifyNewRequest(request, ApplicationGlobals.NEW_REQUEST_NOTIFY_ADDRESS)
    'End Sub

    'Public Sub DeleteRequest(requestId As Integer, user As String)
    '    Using dc As New OT_RequestDataContext(connection)
    '        Dim request As OT_Request = dc.OT_Requests.Single(Function(r) r.SID = requestId)
    '        request.SoftDelete = True
    '        request.ModifiedBy = user
    '        request.DateModified = Now
    '        dc.SubmitChanges()
    '    End Using
    'End Sub

    'Public Sub DecideRequest(requestId As Integer, user As String, decisionID As Integer)
    '    Using dc As New OT_RequestDataContext(connection)
    '        Dim request As OT_Request = dc.OT_Requests.Single(Function(r) r.SID = requestId)
    '        If request.DecisionSID <> decisionID Then
    '            request.DecisionSID = decisionID
    '            request.DecisionBy = user
    '            request.ApprovalDate = Now
    '            request.ModifiedBy = user
    '            request.DateModified = Now
    '            dc.SubmitChanges()
    '            NotifyDecision(request)
    '        End If
    '    End Using
    'End Sub

    'Public Sub ResolveRequest(request As OT_Request, user As String, actualBeginDate As Date,
    '    actualBeginTime As Integer, actualEndDate As Date, actualEndTime As Integer,
    '    actualWorkedFrom As String, actualPOC As String, actualDetails As String, resolution As String)
    '    If Not request.IsResolved Then
    '        Using dc As New OT_RequestDataContext(connection)
    '            request = (From r In dc.OT_Requests Where r.SID = request.SID Select r).Single()
    '            request.ActualBeginDate = actualBeginDate
    '            request.ActualBeginTime = actualBeginTime
    '            request.ActualEndDate = actualEndDate
    '            request.ActualEndTime = actualEndTime
    '            request.ActualTotalHours = request.ActualTotalHoursComp
    '            request.WorkedFrom = actualWorkedFrom
    '            request.MedicalCenterPOC = actualPOC
    '            request.WorkDetails = actualDetails
    '            request.Resolution = resolution
    '            request.ResolutionDate = Now
    '            request.ModifiedBy = user
    '            request.DateModified = Now
    '            dc.SubmitChanges()

    '            NotifyResolution(request, ApplicationGlobals.NEW_REQUEST_NOTIFY_ADDRESS)
    '        End Using
    '    End If
    'End Sub

    Public Sub NewRequest(request As OT_Request, recipient As String)
        Dim fromAddr As String
        CommonFunctions.GetActiveDirectoryInfo(request.EnteredBy, Nothing, Nothing, Nothing, fromAddr, Nothing)
        Using msg As New MailMessage(fromAddr, recipient)
            'msg.From = New MailAddress("no-reply@va.gov", "Overtime Requests")
            msg.Subject = "New Overtime Request for " & request.EmployeeName

            Dim requrl = CommonFunctions.GetAppSettings("ViewRequestUrl") & "?id=" & request.SID
            msg.IsBodyHtml = True
            msg.Body = String.Format("New <a href=""{0}"">overtime request</a> submitted for {1}", requrl, request.EmployeeName)

            Dim client As New SmtpClient
            client.Send(msg)
        End Using
    End Sub

    Public Sub Decision(request As OT_Request)
        Dim fromAddr, toAddr, fname, lname As String
        CommonFunctions.GetActiveDirectoryInfo(request.ModifiedBy, fname, lname, Nothing, fromAddr, Nothing)
        CommonFunctions.GetActiveDirectoryInfo(request.Employee, Nothing, Nothing, Nothing, toAddr, Nothing)

        Dim requrl = CommonFunctions.GetAppSettings("ViewRequestUrl") & "?id=" & request.SID

        Dim client As New SmtpClient

        Using msg As New MailMessage(fromAddr, toAddr)
            msg.Subject = "Overtime Request " & request.Decision.Name

            msg.IsBodyHtml = True
            msg.Body = String.Format("Your <a href=""{0}"">overtime request</a> was {1} by {2}.", requrl, request.Decision.Name.ToLower(), fname & " " & lname)
            If request.Decision.Name = "Approved" AndAlso request.RequestType.ResolutionRequired Then
                msg.Body = msg.Body & " <strong>Please remember to resolve this request upon completion.</strong>"
            End If

            client.Send(msg)
        End Using

        If request.Decision.Name = "Approved" Then
            Using msg As New MailMessage(fromAddr, CommonFunctions.GetAppSettings("ApproveRequestNotify"))
                msg.Subject = request.EmployeeName & "'s Overtime Request " & request.Decision.Name

                msg.IsBodyHtml = True
                msg.Body = String.Format("{3}'s <a href=""{0}"">overtime request</a> was {1} by {2}.", requrl, request.Decision.Name.ToLower(), fname & " " & lname, request.EmployeeName)

                client.Send(msg)
            End Using
        End If
    End Sub

    Public Sub Resolution(request As OT_Request, recipient As String)
        Dim fromAddr As String
        CommonFunctions.GetActiveDirectoryInfo(request.ModifiedBy, Nothing, Nothing, Nothing, fromAddr, Nothing)
        Using msg As New MailMessage(fromAddr, recipient)
            'msg.From = New MailAddress("no-reply@va.gov", "Overtime Requests")
            msg.Subject = "Resolution of Overtime Request for " & request.EmployeeName

            Dim requrl = CommonFunctions.GetAppSettings("ViewRequestUrl") & "?id=" & request.SID
            msg.IsBodyHtml = True
            msg.Body = String.Format("<a href=""{0}"">Overtime request</a> resolved for {1}", requrl, request.EmployeeName)

            If request.RequestType.Name = "Scheduled" AndAlso request.ActualTotalHours > 1 AndAlso request.ActualTotalHours > 1.25 * request.TotalHours Then
                msg.Body = String.Format("<span style=""color: red"">Actual time exceeded scheduled.</span><a href=""{0}""><br />Overtime request</a> resolved for {1}", requrl, request.EmployeeName)
            End If
            Dim client As New SmtpClient
            client.Send(msg)
        End Using
    End Sub
End Module
