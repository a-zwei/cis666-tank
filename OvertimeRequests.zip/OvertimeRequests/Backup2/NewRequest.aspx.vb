﻿Imports System.Linq
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/NewRequest.aspx.vb 10    10/31/12 4:02p Vhaclemauref $
'
Public Class NewRequest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)
    End Sub

    Protected Function TextBoxValueAsHour(tb As TextBox) As Double
        Return CDbl(tb.Text.Substring(0, 2)) + CDbl(tb.Text.Substring(2)) / 60
    End Function

    Protected Function TotalHours() As Double
        Return TextBoxValueAsHour(EndTimeTextBox) - TextBoxValueAsHour(BeginTimeTextBox) + _
            (EndDateCalendar.SelectedDate - BeginDateCalendar.SelectedDate).TotalHours
    End Function

    Protected Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        If IsValid Then
            Dim otRequest As New OT_Request With {
                .Employee = EmployeeDDL.SelectedValue,
                .ServiceLineSID = ServiceLineDDL.SelectedValue,
                .EnteredBy = CommonFunctions.GetNetworkID.ToLower(),
                .RequestTypeSID = RequestTypeDDL.SelectedValue,
                .RequestDate = Now,
                .BeginDate = BeginDateCalendar.SelectedDate,
                .BeginTime = CInt(BeginTimeTextBox.Text),
                .EndDate = EndDateCalendar.SelectedDate,
                .EndTime = CInt(EndTimeTextBox.Text),
                .TotalHours = TotalHours(),
                .ShortDescription = BriefDescriptionTextBox.Text,
                .WorkDetails = DetailsTextBox.Text,
                .WorkedFrom = WorkedFromTextBox.Text,
                .MedicalCenterPOC = POCTextBox.Text,
                .Supervisor = SupervisorDDL.SelectedValue,
                .PayComp = PayCompRBL.SelectedValue
            }
            otRequest.TotalHours = otRequest.TotalHoursComp

            Using dc As New OT_RequestDataContext(Master.DbConnectionString)
                dc.NewRequest(otRequest)
            End Using

            'Response.Redirect("~/ViewRequest.aspx?id=" & otRequest.SID)
            Response.Redirect("~/")
        End If
    End Sub

    Protected Sub TimeValidator_ServerValidate(source As Object, args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles EndTimeValidator.ServerValidate, BeginTimeValidator.ServerValidate
        Try
            Dim time As Integer = CInt(args.Value)
            args.IsValid = time >= 0 AndAlso time < 2400 AndAlso Regex.IsMatch(args.Value, "^[0-2][0-9][0-5][0-9]$")
        Catch
            args.IsValid = False
        End Try
    End Sub

    Protected Sub EmployeeDDL_DataBound(sender As Object, e As EventArgs) Handles EmployeeDDL.DataBound
        EmployeeDDL.SelectedValue = CommonFunctions.GetNetworkID.ToLower()
    End Sub

    Protected Sub RequestTypeDataSource_ContextCreating(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceContextEventArgs) Handles RequestDataSource.ContextCreating, RequestTypeDataSource.ContextCreating, ServiceLineDataSource.ContextCreating
        e.ObjectInstance = New OT_RequestDataContext(Master.DbConnectionString)
    End Sub

    Protected Sub FillDefaultSupervisor()
        Using dc As New OT_RequestDataContext(Master.DbConnectionString)
            Dim supervisorID As String = (From s In dc.DefaultSupervisors Where s.Employee = EmployeeDDL.SelectedValue Select s.Supervisor).SingleOrDefault()
            If Not String.IsNullOrEmpty(supervisorID) AndAlso SupervisorDDL.Items.FindByValue(supervisorID) IsNot Nothing Then
                SupervisorDDL.SelectedValue = supervisorID
            End If
        End Using
    End Sub

    Protected Sub FillDefaultServiceLine()
        Using dc As New OT_RequestDataContext(Master.DbConnectionString)
            Dim serviceLineID As Integer = (From s In dc.DefaultServiceLines Where s.Employee = EmployeeDDL.SelectedValue Select s.ServiceLineSID).SingleOrDefault()
            If serviceLineID > 0 Then
                ServiceLineDDL.SelectedValue = serviceLineID
            End If
        End Using
    End Sub

    Protected Sub EmployeeDDL_SelectedIndexChanged(sender As Object, e As EventArgs) Handles EmployeeDDL.SelectedIndexChanged, SupervisorDDL.DataBound
        FillDefaultSupervisor()
        FillDefaultServiceLine()
    End Sub

    Protected Sub BeginDateCalendar_SelectionChanged(sender As Object, e As EventArgs) Handles BeginDateCalendar.SelectionChanged
        If BeginDateCalendar.SelectedDate > EndDateCalendar.SelectedDate Then
            EndDateCalendar.SelectedDate = BeginDateCalendar.SelectedDate
        End If
    End Sub

    Protected Sub EndDateCalendar_SelectionChanged(sender As Object, e As EventArgs) Handles EndDateCalendar.SelectionChanged
        If BeginDateCalendar.SelectedDate > EndDateCalendar.SelectedDate Then
            BeginDateCalendar.SelectedDate = EndDateCalendar.SelectedDate
        End If
    End Sub

    Protected Sub BeginDateValidator_ServerValidate(source As Object, args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles BeginDateValidator.ServerValidate
        args.IsValid = BeginDateCalendar.SelectedDate > DateTime.MinValue
    End Sub

    Protected Sub EndDateValidator_ServerValidate(source As Object, args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles EndDateValidator.ServerValidate
        args.IsValid = EndDateCalendar.SelectedDate > DateTime.MinValue
    End Sub

    Protected Sub MainMenu_MenuItemDataBound(sender As Object, e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ApplicationFunctions.SetMenu(e, User)
    End Sub
End Class