Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/SecurityAccessError.aspx.vb 1     1/10/12 11:55a Vhaclemauref $
'
Partial Public Class SecurityAccessError
    Inherits System.Web.UI.Page

#Region "Data"
    Protected MessageText_ As String
#End Region

#Region "Page Events"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim MessageStr As String
        Dim MessageNbr As Integer

        Master.EnableMedicalCenterDDLB()

        MessageStr = Request.QueryString("message")
        MessageNbr = CInt(MessageStr)

        If MessageNbr = CommonGlobals.APP_ACCESS_DENIED Then
            If Master.CbocSupportWebConfig Then
                MessageText_ = "You do not have access to the requested web page for the Medical Center and CBOC selected<br />or have not accessed the application's home page first."
            Else
                MessageText_ = "You do not have access to the requested web page for the Medical Center selected<br />or have not accessed the application's home page first."
            End If
        ElseIf MessageNbr = CommonGlobals.APP_ACCESS_DENIED_UNRESTRICTED Then
            MessageText_ = "The requested web application is currently not supported for the Medical Center selected<br />or you have not accessed the application's home page first."
        ElseIf MessageNbr = CommonGlobals.APP_DISABLED Then
            MessageText_ = "The requested web application is current down for maintenance."
        ElseIf MessageNbr = CommonGlobals.USER_DISABLED Then
            MessageText_ = "Your web application access has been disabled."
        Else
            MessageText_ = "System Error: Message Not Found"
        End If
    End Sub
#End Region

End Class