﻿Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/MyRequests.aspx.vb 4     1/31/12 3:02p Vhaclemauref $
'
Public Class MyRequests
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)

        RequestDataSource.WhereParameters("Employee").DefaultValue = CommonFunctions.GetNetworkID().ToLower()
    End Sub

    Protected Sub RequestDataSource_ContextCreating(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceContextEventArgs) Handles RequestDataSource.ContextCreating
        e.ObjectInstance = New OT_RequestDataContext(Master.DbConnectionString)
    End Sub

    Protected Sub RequestGridView_SelectedIndexChanging(sender As Object, e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles RequestGridView.SelectedIndexChanging
        Response.Redirect("~/ViewRequest.aspx?id=" & RequestGridView.DataKeys(e.NewSelectedIndex).Value)
    End Sub

    Protected Sub RequestGridView_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles RequestGridView.RowCommand
        If e.CommandName = "Resolve" Then
            Response.Redirect("~/ResolveRequest.aspx?id=" & RequestGridView.DataKeys(e.CommandArgument).Value)
        End If
    End Sub

    Protected Sub RequestGridView_RowDataBound(sender As Object, e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles RequestGridView.RowDataBound
        Dim otRequest As OT_Request = e.Row.DataItem
        If otRequest IsNot Nothing AndAlso (otRequest.IsResolved OrElse otRequest.Decision.Name = "Denied") Then
            e.Row.Cells(10).Visible = False
        End If
    End Sub

    Protected Sub MainMenu_MenuItemDataBound(sender As Object, e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ApplicationFunctions.SetMenu(e, User)
    End Sub
End Class