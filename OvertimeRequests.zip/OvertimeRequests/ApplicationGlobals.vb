'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ApplicationGlobals.vb 7     10/03/13 10:20a Vhaclemauref $
'
Public Class ApplicationGlobals

#Region "Data"
    Public Const APPLICATION_ID As Integer = 229
    Public Const MANAGER As String = "VHACLEIRMMAN"
#End Region

#Region "Constructors"
    Private Sub New()
		' Private constructor prevents instantiation outside the class
	End Sub
#End Region

End Class
