Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/Common.Master.vb 1     1/10/12 11:55a Vhaclemauref $
'
Public Class Common
    Inherits System.Web.UI.MasterPage

#Region "Data"
    Protected ApplicationName_ As String
    Protected DatabaseName_ As String
    Protected CbocSupportWebConfig_ As Boolean
    Protected ShowMedicalCenterWithCbocs_ As Boolean
    Protected DbConnectionString_ As String

    Protected WelcomeLink_ As String

    Protected CbocNameCollection_ As New StringCollection()

    Public CommonSecurity As CommonSecurity
#End Region

#Region "Public Property Methods"
    Public ReadOnly Property ApplicationName() As String
        Get
            Return ApplicationName_
        End Get
    End Property

    Public ReadOnly Property DatabaseName() As String
        Get
            Return DatabaseName_
        End Get
    End Property

    Public ReadOnly Property CbocSupportWebConfig() As Boolean
        Get
            Return CbocSupportWebConfig_
        End Get
    End Property

    Public ReadOnly Property ShowMedicalCenterWithCbocs() As Boolean
        Get
            Return ShowMedicalCenterWithCbocs_
        End Get
    End Property

    Public ReadOnly Property DbConnectionString() As String
        Get
            Return DbConnectionString_
        End Get
    End Property
#End Region

#Region "Page Events"
    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Dim UserID As String
        Dim NewMedicalCenterString As String
        Dim MedicalCenterNameCollection As New StringCollection()
        Dim MedicalCenterString As String = ""
        Dim MedicalCenterLocation As String = ""
        Dim MedicalCenterID As Integer = -1
        Dim NewCbocString As String = ""
        Dim i As Integer

        ' Web.config
        ApplicationName_ = CommonFunctions.GetAppSettings("ApplicationName")
        DatabaseName_ = CommonFunctions.GetAppSettings("DatabaseName")
        CbocSupportWebConfig_ = CommonFunctions.GetAppSettingsBoolean("CbocSupport")
        ShowMedicalCenterWithCbocs_ = CommonFunctions.GetAppSettingsBoolean("ShowMedicalCenterWithCbocs")
        Dim ShowWelcomeLink As Boolean = CommonFunctions.GetAppSettingsBoolean("ShowWelcomeLink")
        ' Getting ALL "appSettings" variables from Web.config file here, to check if they exist.
        ' If not, an exception error will be thrown notify that its missing.
        Dim AppErrorEmailAddress As String = CommonFunctions.GetAppSettings("AppErrorEmailAddress")
        DbConnectionString_ = "Data Source=" & CommonGlobals.DbServerName & "; Initial Catalog=" & DatabaseName_ & "; Integrated Security=SSPI"
        Dim AppWebRootFolder As String = CommonGlobals.AppWebRootFolder

        If ShowWelcomeLink = True Then
            WelcomeLink_ = "<a href=""" & AppWebRootFolder & "/Welcome/"" class=""titlebarItem"">Welcome</a>"
        Else
            WelcomeLink_ = "Welcome"
        End If

        ' Used so reading  Request.Form("CommonMaster$ControlID")
        ' instead of Request.Form("ctl00$MedicalCenterDDLB") in request.
        ' Needed because Request.Form() parameter is different when using a Master Page.
        Me.ID = "CommonMaster"

        If Request.Form("CommonMaster$MedicalCenterDDLB") IsNot Nothing Then
            NewMedicalCenterString = Request.Form("CommonMaster$MedicalCenterDDLB").ToString()
        Else
            NewMedicalCenterString = ""
        End If


        If CbocSupportWebConfig_ Then
            If Request.Form("CommonMaster$CbocDDLB") IsNot Nothing Then
                NewCbocString = Request.Form("CommonMaster$CbocDDLB").ToString()
            Else
                NewCbocString = ""
            End If

            ' display CBOC DDLB field
            cbocdiv.Visible = True
        Else
            cbocdiv.Visible = False
        End If

        UserID = CommonFunctions.GetNetworkID()
        UserIDFld.Text = UserID

        CommonSecurity = New CommonSecurity(CbocSupportWebConfig_, ShowMedicalCenterWithCbocs_, ShowWelcomeLink)
        CommonSecurity.SetMedicalCenter(NewMedicalCenterString, MedicalCenterNameCollection, NewCbocString, CbocNameCollection_, ApplicationGlobals.APPLICATION_ID)

        If Not IsPostBack Then
            Dim DdlbItem As ListItem
            Dim nbr As Integer = MedicalCenterNameCollection.Count()
            MedicalCenterDDLB.Items.Clear()
            ' Build Medical Center DDLB
            If nbr > 0 Then
                For i = 0 To (nbr - 1) Step 2
                    DdlbItem = New ListItem

                    MedicalCenterString = MedicalCenterNameCollection.Item(i).ToString()
                    ' MedicalCenterString variable contains both the Location/Name and ID separated by a "~".  Separate them here.
                    If CommonSecurity.ParseMedicalCenterLocationID(MedicalCenterString, MedicalCenterLocation, MedicalCenterID) <> CommonGlobals.SUCCESS Then
                        ' ERROR
                    Else
                        DdlbItem.Text = MedicalCenterLocation
                        DdlbItem.Value = MedicalCenterLocation & "~" & CStr(MedicalCenterID)
                    End If

                    If MedicalCenterLocation = CommonSecurity.MedicalCenterLocation Then
                        DdlbItem.Selected = True
                    Else
                        DdlbItem.Selected = False
                    End If
                    MedicalCenterDDLB.Items.Add(DdlbItem)
                Next
            End If
        End If
    End Sub

    ' Had to set the CBOC DDLB Control's  EnableViewState="False"  and place the code that populates it in
    ' Page_Load() rather than Page_Init() like the Medical Center DDLB.  Had a problem when changing the
    ' Medical Center DDLB value, the CBOC DDLB would NOT display the correct (default) entry.
    Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CbocString As String = ""
        Dim CbocLocation As String = ""
        Dim CbocID As Integer = -1
        Dim DdlbItem As ListItem
        Dim nbr As Integer
        Dim i As Integer

        If CbocSupportWebConfig_ Then
            nbr = CbocNameCollection_.Count()
            CbocDDLB.Items.Clear()
            ' Build CBOC DDLB
            If nbr > 0 Then
                For i = 0 To (nbr - 1) Step 2
                    DdlbItem = New ListItem

                    CbocString = CbocNameCollection_.Item(i).ToString()
                    ' CbocString variable contains both the Location/Name and ID separated by a "~".  Separate them here.
                    If CommonSecurity.ParseCbocLocationID(CbocString, CbocLocation, CbocID) <> CommonGlobals.SUCCESS Then
                        ' ERROR
                    Else
                        DdlbItem.Text = CbocLocation
                        DdlbItem.Value = CbocLocation & "~" & CStr(CbocID)
                    End If

                    If CbocLocation = CommonSecurity.CbocLocation Then
                        DdlbItem.Selected = True
                    Else
                        DdlbItem.Selected = False
                    End If
                    CbocDDLB.Items.Add(DdlbItem)
                Next
            End If
        End If
    End Sub
#End Region

#Region "Methods"
    Public Sub EnableMedicalCenterDDLB()
        MedicalCenterDDLB.Enabled = True
        If CbocSupportWebConfig_ Then
            CbocDDLB.Enabled = True
        End If
    End Sub

    Protected Sub MedicalCenterDDLB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MedicalCenterDDLB.SelectedIndexChanged
        ' Defined here because autopostback needed for Medical Center DDLB.
        ' Real work gets done in CommonSecurity class constructor.
    End Sub

    Protected Sub CbocDDLB_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CbocDDLB.SelectedIndexChanged
        ' Defined here because autopostback needed for CBOC DDLB.
        ' Real work gets done in CommonSecurity class constructor.
    End Sub

    Public Sub SetSecurity(ByVal ApplicationID As Integer)
        Dim rc As Integer

        rc = CommonSecurity.SetSecurity(ApplicationID)
        If rc <> CommonGlobals.SUCCESS Then
            Response.Clear()
            Response.Redirect("~/SecurityAccessError.aspx?message=" & CStr(rc), False)
        End If
    End Sub

    Public Sub CheckSecurity(ByVal ApplicationID As Integer)
        Dim rc As Integer

        rc = CommonSecurity.CheckSecurity(ApplicationID)
        If rc <> CommonGlobals.SUCCESS Then
            Response.Clear()
            Response.Redirect("~/SecurityAccessError.aspx?message=" & CStr(rc), False)
        End If
    End Sub

    Public Sub SetUnrestricted(ByVal ApplicationID As Integer)
        Dim rc As Integer

        rc = CommonSecurity.SetUnrestricted(ApplicationID)
        If rc <> CommonGlobals.SUCCESS Then
            Response.Clear()
            Response.Redirect("~/SecurityAccessError.aspx?message=" & CStr(rc), False)
        End If
    End Sub

    Public Sub CheckUnrestricted(ByVal ApplicationID As Integer)
        Dim rc As Integer

        rc = CommonSecurity.CheckUnrestricted(ApplicationID)
        If rc <> CommonGlobals.SUCCESS Then
            Response.Clear()
            Response.Redirect("~/SecurityAccessError.aspx?message=" & CStr(rc), False)
        End If
    End Sub
#End Region

End Class