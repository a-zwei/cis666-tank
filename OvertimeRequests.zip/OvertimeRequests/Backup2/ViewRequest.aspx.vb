﻿Imports System.Linq
Imports VHACLE.CommonClassLib.CommonVHACLE

'
' Cleveland VA Medical Center
' Developer: Fred Maurer
' $Header: /web_apps/intra/OvertimeRequests/ViewRequest.aspx.vb 11    6/05/12 11:34a Vhaclemauref $
'
Public Class ViewRequest
    Inherits System.Web.UI.Page

    Private otRequest As OT_Request
    Private manager As Boolean = False

    'Protected Function UserOwnsRequest()
    '    Dim user As String = CommonFunctions.GetNetworkID().ToLower()
    '    Return otRequest.Employee = user OrElse otRequest.EnteredBy = user OrElse otRequest.CreatedBy.ToLower() = user
    'End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckSecurity(ApplicationGlobals.APPLICATION_ID)
        'manager = User.IsInRole(ApplicationGlobals.MANAGER)
        Using dc As New IRMStaffDataContext
            manager = dc.UserIsSupervisor(CommonFunctions.GetNetworkID())
        End Using

        Dim reqid As String = Request.QueryString("id")
        If reqid IsNot Nothing Then
            Using dc As New OT_RequestDataContext(Master.DbConnectionString)
                otRequest = dc.OT_Requests.Single(Function(r) r.SID = CInt(reqid))
                SetVisibilities(otRequest)
            End Using
        End If
    End Sub

    Protected Sub SetVisibilities(r As OT_Request)
        StatusLabel.Text = otRequest.Status
        DeletedLabel.Visible = otRequest.SoftDelete
        RequestLeftDetailsView.Visible = Not otRequest.SoftDelete
        RequestRightDetailsView.Visible = Not otRequest.SoftDelete
        DeleteButton.Visible = Not otRequest.SoftDelete AndAlso otRequest.IsPending AndAlso manager 'UserOwnsRequest()
        DecisionButton.Visible = manager AndAlso otRequest.CanDecide
        DecisionDDL.Visible = DecisionButton.Visible
        RequestLeftDetailsView.Rows(4).Visible = otRequest.IsResolved
        RequestLeftDetailsView.Rows(5).Visible = otRequest.IsResolved
        RequestLeftDetailsView.Rows(7).Visible = otRequest.IsResolved
        RequestRightDetailsView.Rows(4).Visible = otRequest.IsResolved
        RequestRightDetailsView.Rows(5).Visible = otRequest.IsResolved
        RequestRightDetailsView.Rows(10).Visible = otRequest.IsResolved
    End Sub

    Protected Sub DataSource_ContextCreating(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceContextEventArgs) Handles RequestDataSource.ContextCreating, DecisionDataSource.ContextCreating
        e.ObjectInstance = New OT_RequestDataContext(Master.DbConnectionString)
    End Sub

    Protected Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        Using dc As New OT_RequestDataContext(Master.DbConnectionString)
            dc.DeleteRequest(otRequest.SID, CommonFunctions.GetNetworkID())
            dc.SubmitChanges()
        End Using

        Response.Redirect(Request.Url.ToString())
    End Sub

    Protected Sub DecisionButton_Click(sender As Object, e As EventArgs) Handles DecisionButton.Click
        If manager Then
            Using dc As New OT_RequestDataContext(Master.DbConnectionString)
                dc.DecideRequest(otRequest.SID, CommonFunctions.GetNetworkID(), DecisionDDL.SelectedValue)
                dc.SubmitChanges()
            End Using

            Response.Redirect("~/Pending.aspx")
        End If
    End Sub

    Protected Sub DecisionDDL_DataBound(sender As Object, e As EventArgs) Handles DecisionDDL.DataBound
        If otRequest IsNot Nothing Then
            DecisionDDL.SelectedValue = otRequest.DecisionSID
        End If
    End Sub

    Protected Sub MainMenu_MenuItemDataBound(sender As Object, e As System.Web.UI.WebControls.MenuEventArgs) Handles MainMenu.MenuItemDataBound
        ApplicationFunctions.SetMenu(e, User)
    End Sub
End Class